<?php

class Student extends DataObject {
	
	static $db = array(
		'FirstName' => 'Text',
		'Lastname' => 'Text',
		'Nationality' => 'Text'
	);
	
	static $has_one = array(
		'MyMentor' => 'Mentor'
	);
	
	function MyProject() {
		return DataObject::get( 'Project', "`MyStudentID` = '{$this->ID}'" );
	}
	
	function getCMSFields_forPopup() {
		$fields = new FieldSet();
		$fields->push( new TextField( 'FirstName', 'First Name' ) );
		$fields->push( new TextField( 'Lastname' ) );
		$fields->push( new TextField( 'Nationality' ) );
		return $fields;
	}
	
	function forTemplate() {
		$template = 'GSOCPerson';
		return $this->renderWith( $template );
	}
	
}

?>
