<?php

class ProjectsHolder extends Page {
	
	static $allowed_children = array( 'Project' );
	
}

class ProjectsHolder_Controller extends Page_Controller {
	
}

?>
