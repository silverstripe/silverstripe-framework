<?php
		
class Mentor extends Page {

	static $db = array(
		'FirstName'=>'VarChar',
		'LastName'=>'VarChar'
	);
	
	static $has_many = array(
		'Students'=>'Student'
	);
	
	public function getCMSFields() {
		$fields = parent::getCMSFields();
		$fields->addFieldToTab('Root.Content', new TextField('FirstName'));
		$fields->addFieldToTab('Root.Content', new TextField('LastName'));
		//Create our config variable and fill it with our desired components 
		$config = GridFieldConfig::create()->addComponents(
		 	//Provide a header with a Title
			new GridFieldToolbarHeader(),			 
			// Provide a header row with sort controls
			new GridFieldSortableHeader(),			 
			// Provide a default set of columns
			$columns = new GridFieldDataColumns(),
			//Add a button to add students
			new GridFieldAddNewButton('after'),
			//The method that handles the add new request
			new GridFieldDetailForm(),
			//Add an edit button 
			new GridFieldEditButton()
		);	

		//Set the names and data for our gridfield columns
		$columns->setDisplayFields(array(
			'FirstName'=>'FirstName',
			'LastName'=>'LastName'
	    ));		
      
		// Create a gridfield to hold the student relationship    
		$gridfield = new GridField(
			'Students',
			'Students',
			 Student::get(),			
			 $config			
		);	   
		
		$fields->addFieldToTab( 'Root.Students', $gridfield );

		return $fields;
	}
	
	public function PersonalInfo() {
		$template = 'Person';
		return $this->renderWith( $template );
	}
}	
class Mentor_Controller extends Page_Controller {}