<?php
class HomePage extends Page {

	static $db = array(

    );

	public static $has_one = array(
	);

	static $icon = "framework/docs/en/tutorials/_images/treeicons/home-file.gif";

}

class HomePage_Controller extends Page_Controller {

	public static $allowed_actions = array (
	);

	public function init() {
		parent::init();

	}

	public function LatestNews($num=5) {
		$holder = ArticleHolder::get()->First();
		return ($holder) ? ArticlePage::get()->filter('ParentID', $holder->ID)->sort('Date DESC')->limit($num) : false;
	}

	public function BrowserPollForm() {
		if(Session::get('BrowserPollVoted')) {
        	return false;
    	}
        // Create fields
        $fields = new FieldList(
            new TextField('Name'),
            new OptionsetField('Browser', 'Your Favourite Browser', array(
                'Firefox' => 'Firefox',
                'Chrome' => 'Chrome',
                'Internet Explorer' => 'Internet Explorer',
                'Safari' => 'Safari',
                'Opera' => 'Opera',
                'Lynx' => 'Lynx'
            ))
        );
        
        // Create actions
        $actions = new FieldList(
            new FormAction('doBrowserPoll', 'Submit')
        );
    
      	// Create validator
		$validator = new RequiredFields('Name', 'Browser');
		
		return new Form($this, 'BrowserPollForm', $fields, $actions, $validator);
    }

    public function doBrowserPoll($data, $form) {
		$submission = new BrowserPollSubmission();
		$form->saveInto($submission);
		$submission->write();
		Session::set('BrowserPollVoted', true);
		return $this->redirectBack();
	}

	public function BrowserPollResults() {
	    $submissions = BrowserPollSubmission::get();
	    $total = $submissions->Count();	    
	    $aList = new ArrayList();

	    foreach(GroupedList::create($submissions)->groupBy('Browser') as $browser => $data) {
	        $percentage = (int) ($data->Count() / $total * 100);
	        $record = array(
	            'Browser' => $browser,
	            'Percentage' => $percentage
	        );
	        $aList->push(new ArrayData($record));
	    }	    
	    return $aList;
	}


}


