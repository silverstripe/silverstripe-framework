<?php

class Module extends DataObject {

   static $db = array(
      'Name' => 'VarChar'
   );

   static $belongs_many_many = array(
      'Projects' => 'Project'
   );



}
