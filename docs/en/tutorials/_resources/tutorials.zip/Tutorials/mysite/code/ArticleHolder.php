<?php
class ArticleHolder extends Page {

	static $db = array(

    );

	public static $has_one = array(
	);

	static $allowed_children = array('ArticlePage');

	static $icon = "framework/docs/en/tutorials/_images/treeicons/news-file.gif";



}
class ArticleHolder_Controller extends Page_Controller {

	public static $allowed_actions = array (
	);

	public function init() {
		parent::init();

	}

}


