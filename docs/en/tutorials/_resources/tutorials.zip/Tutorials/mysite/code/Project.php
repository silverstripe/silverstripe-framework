<?php

class Project extends Page { 

 	static $has_many = array(
	    'Students' => 'Student'
	); 

	static $many_many = array(
	    'Modules' => 'Module'
	); 



	public function getCMSFields() {
		$fields = parent::getCMSFields();

		//Create our config variable and fill it with our desired components 
		$config = GridFieldConfig::create()->addComponents(
		 
			//Provide a header with a Title
			new GridFieldToolbarHeader(),			 
			// Provide a header row with sort controls
			new GridFieldSortableHeader(),			 
			// Provide a default set of columns
			$columns = new GridFieldDataColumns(),
			//Add a button to add students
			new GridFieldAddNewButton('after'),
			//The method that handles the add new request
			new GridFieldDetailForm(),
			//Add an edit button 
			new GridFieldEditButton()
		);	

		//Set the names and data for our gridfield columns
		$columns->setDisplayFields(array(
			'Name' => 'Name'
	    ));		
	
      
		// Create a gridfield to hold the modules relationship    
		$gridfield = new GridField(
			'Modules',
			'Modules',
			 Module::get(),			
			 $config			
		);		      
	
	    $fields->addFieldToTab( 'Root.Modules', $gridfield );
	
	    return $fields;
	}



}
class Project_Controller extends Page_Controller {}