<?php

class Student extends DataObject {

    static $db = array(
        'FirstName' => 'VarChar',
        'LastName' =>'VarChar'        
    );

    static $has_one = array(
        'Project' => 'Project',
        'Mentor' => 'Mentor'
    );

    public function PersonalInfo() {
        $template = 'Person';
        return $this->renderWith( $template );
    }
    
}