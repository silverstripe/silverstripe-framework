<?php

class ProjectsHolder extends Page {

	static $has_many = array(
        'Students' => 'Student'
    );

    static $allowed_children = array( 'Project' );

    public function getCMSFields() {
        $fields = parent::getCMSFields();

        $config = GridFieldConfig::create()->addComponents(
        	//Provide a header with a Title
			new GridFieldToolbarHeader(),
			// Provide a header row with sort controls
			new GridFieldSortableHeader(),
			// Provide a default set of columns
			$columns = new GridFieldDataColumns(),
			//Add a button to add students
			new GridFieldAddNewButton('after'),
			new GridFieldDetailForm(),
			new GridFieldEditButton()
		);		

		//Set the names of our gridfield columns
		$columns->setDisplayFields(array(
		    'FirstName' => 'First Name',
        	'Lastname' => 'Last Name',
        	'Project.Title'=> 'Project'
		));	
	     
	    // Create a gridfield to hold the student relationship    
		$gridfield = new GridField(
			'Students',
			'Student',
			 Student::get(),			
			 $config
		);

		//Create a tab named "Student" and add our gridfield to it.		
		$fields->addFieldToTab('Root.Students', $gridfield); 
		
        return $fields; 
    }

}

class ProjectsHolder_Controller extends Page_Controller {

}