<?php

class Module extends DataObject {
	
	static $db = array(
		'Name' => 'Text'
	);
	
	static $belongs_many_many = array(
		'Projects' => 'Project'
	);
	
	function getCMSFields_forPopup() {
		$fields = new FieldSet();
		$fields->push( new TextField( 'Name' ) );
		return $fields;
	}
	
}

?>
